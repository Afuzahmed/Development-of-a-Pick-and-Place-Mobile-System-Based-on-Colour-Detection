Libaray used 

1) Numpy 
2) opencv
3) math
4) tkinter
5) pyserial
6) PyCMDmessenger
7) requests
8) imutils

Also install pycmdmessenger for arduino